<?php
/**
 * GixFlow Update Center – Update 1
 * Standalone PHP updater for remote JSON feeds, ordered ZIP packages, manual upload,
 * backups and AJAX status reporting.
 */
class GixflowUpdater
{
    private $root;
    private $baseDir;
    private $stateDir;
    private $configFile;
    private $statusFile;
    private $installedFile;
    private $lockFile;
    private $config;

    public function __construct($root = null)
    {
        $this->root = $root ? rtrim($root, DIRECTORY_SEPARATOR) : realpath(__DIR__ . '/../../..');
        if (!$this->root) {
            throw new Exception('GixFlow Root konnte nicht ermittelt werden.');
        }
        $this->baseDir = $this->root . '/cms/update';
        $this->stateDir = $this->baseDir . '/state';
        $this->configFile = $this->stateDir . '/update-config.php';
        $this->statusFile = $this->stateDir . '/status.json';
        $this->installedFile = $this->stateDir . '/installed.json';
        $this->lockFile = $this->stateDir . '/update.lock';
        $this->ensureStructure();
        $this->config = $this->loadConfig();
    }

    private function ensureStructure()
    {
        $dirs = array(
            $this->baseDir,
            $this->stateDir,
            $this->baseDir . '/packages',
            $this->baseDir . '/tmp',
            $this->baseDir . '/backups',
            $this->baseDir . '/logs',
            $this->baseDir . '/test-results'
        );
        foreach ($dirs as $dir) {
            if (!is_dir($dir) && !mkdir($dir, 0755, true)) {
                throw new Exception('Ordner konnte nicht erstellt werden: ' . $this->safeDisplayPath($dir));
            }
        }
        if (!file_exists($this->installedFile)) {
            $this->writeJson($this->installedFile, array('installed' => array(), 'updatedAt' => null));
        }
        if (!file_exists($this->statusFile)) {
            $this->writeJson($this->statusFile, $this->defaultStatus());
        }
    }

    private function defaultConfig()
    {
        return array(
            'version' => '11.2-update1',
            'channel' => 'stable',
            'remoteFeedUrl' => 'cms/update/remote-feed/gixflow-updates.local-test.json',
            'autoCheckEnabled' => false,
            'autoInstallEnabled' => false,
            'autoCheckHours' => 12,
            'installStrategy' => 'manual_confirmed',
            'accessToken' => 'CHANGE_ME_UPDATE1',
            'allowedHosts' => array(
                'raw.githubusercontent.com',
                'github.com',
                'gist.githubusercontent.com',
                'dl.dropboxusercontent.com',
                'dropbox.com',
                'drive.google.com'
            ),
            'maxDownloadBytes' => 52428800,
            'backupEnabled' => true,
            'keepBackups' => 8,
            'lastCheckAt' => null,
            'lastFeedTitle' => null
        );
    }

    public function loadConfig()
    {
        $defaults = $this->defaultConfig();
        if (!file_exists($this->configFile)) {
            $this->savePhpConfig($defaults);
            return $defaults;
        }
        $data = include $this->configFile;
        if (!is_array($data)) {
            $data = array();
        }
        return array_merge($defaults, $data);
    }

    private function savePhpConfig(array $data)
    {
        $export = var_export($data, true);
        $php = "<?php\n// GixFlow Update Center private config. Nicht als JSON ausliefern.\nreturn " . $export . ";\n";
        if (file_put_contents($this->configFile, $php, LOCK_EX) === false) {
            throw new Exception('Update-Konfiguration konnte nicht geschrieben werden.');
        }
        @chmod($this->configFile, 0640);
    }

    public function publicConfig()
    {
        $cfg = $this->config;
        unset($cfg['accessToken']);
        $cfg['tokenIsDefault'] = ($this->config['accessToken'] === 'CHANGE_ME_UPDATE1');
        $cfg['paths'] = array(
            'updateCenter' => 'admin/update-center.php',
            'state' => 'cms/update/state',
            'packages' => 'cms/update/packages',
            'backups' => 'cms/update/backups'
        );
        return $cfg;
    }

    public function saveConfigFromInput(array $input)
    {
        $cfg = $this->config;
        $textKeys = array('remoteFeedUrl', 'channel', 'installStrategy');
        foreach ($textKeys as $key) {
            if (isset($input[$key])) {
                $cfg[$key] = trim((string)$input[$key]);
            }
        }
        foreach (array('autoCheckEnabled', 'autoInstallEnabled', 'backupEnabled') as $key) {
            if (isset($input[$key])) {
                $cfg[$key] = filter_var($input[$key], FILTER_VALIDATE_BOOLEAN);
            }
        }
        foreach (array('autoCheckHours', 'maxDownloadBytes', 'keepBackups') as $key) {
            if (isset($input[$key])) {
                $cfg[$key] = max(1, (int)$input[$key]);
            }
        }
        if (isset($input['allowedHosts'])) {
            if (is_array($input['allowedHosts'])) {
                $hosts = $input['allowedHosts'];
            } else {
                $hosts = preg_split('/[,\n]+/', (string)$input['allowedHosts']);
            }
            $clean = array();
            foreach ($hosts as $host) {
                $host = strtolower(trim($host));
                if ($host !== '' && preg_match('/^[a-z0-9.-]+$/', $host)) {
                    $clean[] = $host;
                }
            }
            $cfg['allowedHosts'] = array_values(array_unique($clean));
        }
        if (!empty($input['newAccessToken'])) {
            $new = trim((string)$input['newAccessToken']);
            if (strlen($new) < 12) {
                throw new Exception('Der neue Sicherheitstoken muss mindestens 12 Zeichen lang sein.');
            }
            $cfg['accessToken'] = $new;
        }
        $cfg['version'] = '11.2-update1';
        $this->savePhpConfig($cfg);
        $this->config = $cfg;
        $this->log('Konfiguration gespeichert.');
        return $this->publicConfig();
    }

    public function assertToken($token)
    {
        $expected = (string)$this->config['accessToken'];
        $token = (string)$token;
        if ($expected === '' || $token === '' || !hash_equals($expected, $token)) {
            throw new Exception('Zugriff verweigert: Sicherheitstoken fehlt oder ist falsch.');
        }
    }

    public function selfTest()
    {
        $checks = array();
        $checks[] = array('label' => 'PHP-Version', 'ok' => version_compare(PHP_VERSION, '7.4.0', '>='), 'value' => PHP_VERSION);
        $zipSupport = class_exists('ZipArchive') ? 'ZipArchive' : (class_exists('PharData') ? 'PharData' : 'fehlt');
        $checks[] = array('label' => 'ZIP-Unterstützung', 'ok' => ($zipSupport !== 'fehlt'), 'value' => $zipSupport);
        foreach (array('cms/update/state', 'cms/update/packages', 'cms/update/backups', 'cms/update/tmp') as $rel) {
            $abs = $this->root . '/' . $rel;
            $checks[] = array('label' => 'Schreibbar: ' . $rel, 'ok' => is_writable($abs), 'value' => is_writable($abs) ? 'ja' : 'nein');
        }
        $checks[] = array('label' => 'Root schreibbar', 'ok' => is_writable($this->root), 'value' => is_writable($this->root) ? 'ja' : 'nein');
        return $checks;
    }

    public function getStatus()
    {
        $status = $this->readJson($this->statusFile, $this->defaultStatus());
        $status['installed'] = $this->getInstalledPackages();
        $status['locked'] = file_exists($this->lockFile);
        return $status;
    }

    public function resetStatus()
    {
        if (file_exists($this->lockFile)) {
            @unlink($this->lockFile);
        }
        $this->writeJson($this->statusFile, $this->defaultStatus('Status zurückgesetzt.'));
        return $this->getStatus();
    }

    private function defaultStatus($message = 'Bereit.')
    {
        return array(
            'state' => 'idle',
            'progress' => 0,
            'message' => $message,
            'currentFile' => null,
            'currentPackage' => null,
            'startedAt' => null,
            'finishedAt' => null,
            'updatedAt' => date('c'),
            'logs' => array(array('time' => date('c'), 'message' => $message))
        );
    }

    private function setStatus($state, array $extra = array())
    {
        $status = $this->readJson($this->statusFile, $this->defaultStatus());
        $status['state'] = $state;
        $status['updatedAt'] = date('c');
        foreach ($extra as $k => $v) {
            $status[$k] = $v;
        }
        $this->writeJson($this->statusFile, $status);
    }

    private function log($message, array $extra = array())
    {
        $status = $this->readJson($this->statusFile, $this->defaultStatus());
        if (!isset($status['logs']) || !is_array($status['logs'])) {
            $status['logs'] = array();
        }
        $entry = array_merge(array('time' => date('c'), 'message' => $message), $extra);
        $status['logs'][] = $entry;
        if (count($status['logs']) > 250) {
            $status['logs'] = array_slice($status['logs'], -250);
        }
        $status['message'] = $message;
        $status['updatedAt'] = date('c');
        $this->writeJson($this->statusFile, $status);
    }

    public function checkFeed($feedUrl = null)
    {
        $feedUrl = $feedUrl ? trim($feedUrl) : $this->config['remoteFeedUrl'];
        if ($feedUrl === '') {
            throw new Exception('Keine Remote-Feed-URL eingetragen.');
        }
        $this->setStatus('checking', array('progress' => 5, 'message' => 'Update-Feed wird geprüft...', 'startedAt' => date('c')));
        $raw = $this->fetchText($feedUrl, 1048576);
        $feed = json_decode($raw, true);
        if (!is_array($feed)) {
            throw new Exception('Update-Feed ist kein gültiges JSON.');
        }
        if (!isset($feed['packages']) || !is_array($feed['packages'])) {
            throw new Exception('Update-Feed enthält keine packages-Liste.');
        }
        $plan = $this->buildPlan($feed);
        $cfg = $this->config;
        $cfg['lastCheckAt'] = date('c');
        $cfg['lastFeedTitle'] = isset($feed['title']) ? (string)$feed['title'] : (isset($feed['project']) ? (string)$feed['project'] : 'GixFlow Feed');
        $this->config = $cfg;
        $this->savePhpConfig($cfg);
        $this->setStatus('idle', array('progress' => 100, 'message' => 'Update-Feed geprüft.', 'finishedAt' => date('c')));
        return array('feed' => $feed, 'plan' => $plan, 'config' => $this->publicConfig());
    }

    public function buildPlan(array $feed)
    {
        $channel = isset($feed['channel']) ? (string)$feed['channel'] : null;
        $packages = $feed['packages'];
        usort($packages, function ($a, $b) {
            $ao = isset($a['order']) ? (int)$a['order'] : 9999;
            $bo = isset($b['order']) ? (int)$b['order'] : 9999;
            if ($ao === $bo) {
                return strcmp((string)($a['id'] ?? ''), (string)($b['id'] ?? ''));
            }
            return $ao <=> $bo;
        });
        $installed = $this->getInstalledPackages();
        $result = array();
        foreach ($packages as $pkg) {
            $id = isset($pkg['id']) ? (string)$pkg['id'] : '';
            if ($id === '') {
                continue;
            }
            $pkgChannel = isset($pkg['channel']) ? (string)$pkg['channel'] : $channel;
            if ($pkgChannel && $this->config['channel'] && $pkgChannel !== $this->config['channel']) {
                continue;
            }
            $requires = isset($pkg['requires']) && is_array($pkg['requires']) ? $pkg['requires'] : array();
            $missing = array();
            foreach ($requires as $req) {
                if (!isset($installed[(string)$req])) {
                    $missing[] = (string)$req;
                }
            }
            $pkg['installed'] = isset($installed[$id]);
            $pkg['missingRequires'] = $missing;
            $pkg['canInstall'] = !$pkg['installed'] && count($missing) === 0 && !empty($pkg['url']);
            $result[] = $pkg;
        }
        return $result;
    }


    public function autoRun($feedUrl = null)
    {
        if (empty($this->config['autoCheckEnabled'])) {
            return array('skipped' => true, 'message' => 'Auto-Check ist deaktiviert.', 'config' => $this->publicConfig());
        }
        $last = !empty($this->config['lastCheckAt']) ? strtotime($this->config['lastCheckAt']) : 0;
        $hours = isset($this->config['autoCheckHours']) ? (int)$this->config['autoCheckHours'] : 12;
        if ($last && (time() - $last) < ($hours * 3600)) {
            return array('skipped' => true, 'message' => 'Auto-Check ist noch nicht fällig.', 'nextCheckAfter' => date('c', $last + ($hours * 3600)), 'config' => $this->publicConfig());
        }
        $this->log('Auto-Run gestartet.');
        $check = $this->checkFeed($feedUrl);
        $installed = array();
        if (!empty($this->config['autoInstallEnabled'])) {
            $guard = 0;
            while ($guard < 50) {
                $guard++;
                $fresh = $this->checkFeed($feedUrl);
                $next = null;
                foreach ($fresh['plan'] as $pkg) {
                    if (!empty($pkg['canInstall'])) {
                        $next = $pkg;
                        break;
                    }
                }
                if (!$next) {
                    break;
                }
                $result = $this->installPackage($next, false);
                $installed[] = array('id' => $next['id'], 'result' => $result);
            }
        }
        return array('skipped' => false, 'message' => 'Auto-Run abgeschlossen.', 'check' => $check, 'installed' => $installed, 'config' => $this->publicConfig());
    }

    public function installPackageFromFeed($packageId, $feedUrl = null, $force = false)
    {
        $feedData = $this->checkFeed($feedUrl);
        foreach ($feedData['plan'] as $pkg) {
            if ((string)$pkg['id'] === (string)$packageId) {
                return $this->installPackage($pkg, $force);
            }
        }
        throw new Exception('Paket wurde im Feed nicht gefunden: ' . $packageId);
    }

    public function installPackage(array $pkg, $force = false)
    {
        $id = isset($pkg['id']) ? (string)$pkg['id'] : '';
        if ($id === '') {
            throw new Exception('Paket-ID fehlt.');
        }
        if (empty($pkg['url'])) {
            throw new Exception('Paket-URL fehlt: ' . $id);
        }
        $installed = $this->getInstalledPackages();
        if (!$force && isset($installed[$id])) {
            return array('skipped' => true, 'message' => 'Paket ist bereits installiert.', 'package' => $installed[$id]);
        }
        if (!empty($pkg['missingRequires'])) {
            throw new Exception('Abhängigkeiten fehlen: ' . implode(', ', $pkg['missingRequires']));
        }
        $this->acquireLock();
        try {
            $this->setStatus('downloading', array(
                'progress' => 2,
                'message' => 'Paket wird geladen: ' . $id,
                'currentPackage' => $id,
                'startedAt' => date('c'),
                'finishedAt' => null
            ));
            $zipFile = $this->downloadPackage($pkg);
            if (!empty($pkg['sha256'])) {
                $hash = hash_file('sha256', $zipFile);
                if (!hash_equals(strtolower((string)$pkg['sha256']), strtolower($hash))) {
                    throw new Exception('SHA256-Prüfsumme stimmt nicht. Erwartet: ' . $pkg['sha256'] . ' / erhalten: ' . $hash);
                }
            }
            $summary = $this->applyZip($zipFile, $id, $pkg);
            $this->markInstalled($id, array(
                'id' => $id,
                'title' => isset($pkg['title']) ? $pkg['title'] : $id,
                'version' => isset($pkg['version']) ? $pkg['version'] : null,
                'installedAt' => date('c'),
                'files' => $summary['files'],
                'backupDir' => $summary['backupDir'],
                'source' => isset($pkg['url']) ? $pkg['url'] : 'upload'
            ));
            $this->cleanupBackups();
            $this->setStatus('done', array('progress' => 100, 'message' => 'Paket installiert: ' . $id, 'finishedAt' => date('c'), 'currentFile' => null));
            return array('installed' => true, 'packageId' => $id, 'summary' => $summary, 'status' => $this->getStatus());
        } catch (Exception $e) {
            $this->setStatus('error', array('message' => $e->getMessage(), 'finishedAt' => date('c')));
            throw $e;
        } finally {
            $this->releaseLock();
        }
    }

    public function installUploadedFile(array $file)
    {
        if (!class_exists('ZipArchive') && !class_exists('PharData')) {
            throw new Exception('Weder ZipArchive noch PharData ist auf diesem Hosting aktiv.');
        }
        if (empty($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            throw new Exception('Keine gültige Upload-Datei erhalten.');
        }
        if (!empty($file['error'])) {
            throw new Exception('Upload-Fehler-Code: ' . (int)$file['error']);
        }
        $name = preg_replace('/[^a-zA-Z0-9._-]+/', '-', basename($file['name']));
        if (!preg_match('/\.zip$/i', $name)) {
            throw new Exception('Nur ZIP-Dateien sind erlaubt.');
        }
        $target = $this->baseDir . '/packages/upload-' . date('Ymd-His') . '-' . $name;
        if (!move_uploaded_file($file['tmp_name'], $target)) {
            throw new Exception('Upload konnte nicht gespeichert werden.');
        }
        $id = 'manual-' . date('Ymd-His') . '-' . preg_replace('/\.zip$/i', '', $name);
        $pkg = array('id' => $id, 'title' => 'Manuelles ZIP: ' . $name, 'version' => null, 'url' => $target, 'type' => 'manual-upload');
        return $this->installPackage($pkg, true);
    }

    private function downloadPackage(array $pkg)
    {
        $url = (string)$pkg['url'];
        if (preg_match('#^https?://#i', $url)) {
            $this->assertAllowedHost($url);
            $raw = $this->fetchText($url, (int)$this->config['maxDownloadBytes']);
            $filename = preg_replace('/[^a-zA-Z0-9._-]+/', '-', basename(parse_url($url, PHP_URL_PATH)));
            if ($filename === '' || !preg_match('/\.zip$/i', $filename)) {
                $filename = (isset($pkg['id']) ? $pkg['id'] : 'package') . '.zip';
            }
            $target = $this->baseDir . '/packages/' . date('Ymd-His') . '-' . $filename;
            if (file_put_contents($target, $raw, LOCK_EX) === false) {
                throw new Exception('Download konnte nicht gespeichert werden.');
            }
            return $target;
        }
        $path = $this->resolveLocalPath($url);
        if (!is_file($path)) {
            throw new Exception('Lokales Paket nicht gefunden: ' . $url);
        }
        return $path;
    }

    private function applyZip($zipFile, $packageId, array $pkg)
    {
        if (class_exists('ZipArchive')) {
            return $this->applyZipWithZipArchive($zipFile, $packageId, $pkg);
        }
        if (class_exists('PharData')) {
            return $this->applyZipWithPharData($zipFile, $packageId, $pkg);
        }
        throw new Exception('Weder ZipArchive noch PharData ist auf diesem Hosting aktiv.');
    }

    private function applyZipWithZipArchive($zipFile, $packageId, array $pkg)
    {
        $zip = new ZipArchive();
        if ($zip->open($zipFile) !== true) {
            throw new Exception('ZIP konnte nicht geöffnet werden: ' . basename($zipFile));
        }
        $backupDir = $this->baseDir . '/backups/' . date('Ymd-His') . '-' . preg_replace('/[^a-zA-Z0-9._-]+/', '-', $packageId);
        $installedFiles = array();
        $total = max(1, $zip->numFiles);
        if ($this->config['backupEnabled'] && !is_dir($backupDir)) {
            mkdir($backupDir, 0755, true);
        }
        for ($i = 0; $i < $zip->numFiles; $i++) {
            $stat = $zip->statIndex($i);
            if (!$stat || empty($stat['name'])) {
                continue;
            }
            $name = str_replace('\\', '/', $stat['name']);
            if (substr($name, -1) === '/') {
                continue;
            }
            if ($name === 'gixflow-package.json' || strpos($name, '__MACOSX/') === 0) {
                continue;
            }
            $rel = $this->normalizeRelativePath($name);
            $target = $this->root . '/' . $rel;
            $progress = 10 + (int)floor(($i / $total) * 85);
            $this->setStatus('installing', array('progress' => $progress, 'message' => 'Installiere Datei: ' . $rel, 'currentFile' => $rel, 'currentPackage' => $packageId));
            $targetDir = dirname($target);
            if (!is_dir($targetDir) && !mkdir($targetDir, 0755, true)) {
                throw new Exception('Zielordner konnte nicht erstellt werden: ' . $rel);
            }
            if ($this->config['backupEnabled'] && is_file($target)) {
                $backupTarget = $backupDir . '/' . $rel;
                $backupTargetDir = dirname($backupTarget);
                if (!is_dir($backupTargetDir)) {
                    mkdir($backupTargetDir, 0755, true);
                }
                if (!copy($target, $backupTarget)) {
                    throw new Exception('Backup konnte nicht erstellt werden: ' . $rel);
                }
            }
            $stream = $zip->getStream($stat['name']);
            if (!$stream) {
                throw new Exception('ZIP-Eintrag konnte nicht gelesen werden: ' . $rel);
            }
            $out = fopen($target, 'wb');
            if (!$out) {
                fclose($stream);
                throw new Exception('Zieldatei konnte nicht geschrieben werden: ' . $rel);
            }
            stream_copy_to_stream($stream, $out);
            fclose($stream);
            fclose($out);
            @chmod($target, 0644);
            $installedFiles[] = $rel;
        }
        $zip->close();
        $backupManifest = array('packageId' => $packageId, 'createdAt' => date('c'), 'files' => $installedFiles);
        if ($this->config['backupEnabled']) {
            $this->writeJson($backupDir . '/backup-manifest.json', $backupManifest);
        }
        $this->log('Installierte Dateien: ' . count($installedFiles), array('packageId' => $packageId));
        return array('files' => $installedFiles, 'fileCount' => count($installedFiles), 'backupDir' => $this->safeDisplayPath($backupDir), 'engine' => 'ZipArchive');
    }

        
    private function applyZipWithPharData($zipFile, $packageId, array $pkg)
    {
        try {
            $phar = new PharData($zipFile);
        } catch (Exception $e) {
            throw new Exception('ZIP konnte mit PharData nicht geöffnet werden: ' . $e->getMessage());
        }
        $backupDir = $this->baseDir . '/backups/' . date('Ymd-His') . '-' . preg_replace('/[^a-zA-Z0-9._-]+/', '-', $packageId);
        $installedFiles = array();
        $entries = array();
        $prefix = 'phar://' . str_replace('\\', '/', $zipFile) . '/';
        foreach (new RecursiveIteratorIterator($phar) as $file) {
            if ($file->isDir()) {
                continue;
            }
            $pathName = str_replace('\\', '/', $file->getPathName());
            $name = strpos($pathName, $prefix) === 0 ? substr($pathName, strlen($prefix)) : basename($pathName);
            if ($name === 'gixflow-package.json' || strpos($name, '__MACOSX/') === 0) {
                continue;
            }
            $entries[] = array('name' => $name, 'path' => $pathName);
        }
        $total = max(1, count($entries));
        if ($this->config['backupEnabled'] && !is_dir($backupDir)) {
            mkdir($backupDir, 0755, true);
        }
        foreach ($entries as $i => $entry) {
            $rel = $this->normalizeRelativePath($entry['name']);
            $target = $this->root . '/' . $rel;
            $progress = 10 + (int)floor(($i / $total) * 85);
            $this->setStatus('installing', array('progress' => $progress, 'message' => 'Installiere Datei: ' . $rel, 'currentFile' => $rel, 'currentPackage' => $packageId));
            $targetDir = dirname($target);
            if (!is_dir($targetDir) && !mkdir($targetDir, 0755, true)) {
                throw new Exception('Zielordner konnte nicht erstellt werden: ' . $rel);
            }
            if ($this->config['backupEnabled'] && is_file($target)) {
                $backupTarget = $backupDir . '/' . $rel;
                $backupTargetDir = dirname($backupTarget);
                if (!is_dir($backupTargetDir)) {
                    mkdir($backupTargetDir, 0755, true);
                }
                if (!copy($target, $backupTarget)) {
                    throw new Exception('Backup konnte nicht erstellt werden: ' . $rel);
                }
            }
            $content = file_get_contents($entry['path']);
            if ($content === false) {
                throw new Exception('ZIP-Eintrag konnte nicht gelesen werden: ' . $rel);
            }
            if (file_put_contents($target, $content, LOCK_EX) === false) {
                throw new Exception('Zieldatei konnte nicht geschrieben werden: ' . $rel);
            }
            @chmod($target, 0644);
            $installedFiles[] = $rel;
        }
        $backupManifest = array('packageId' => $packageId, 'createdAt' => date('c'), 'files' => $installedFiles, 'engine' => 'PharData');
        if ($this->config['backupEnabled']) {
            $this->writeJson($backupDir . '/backup-manifest.json', $backupManifest);
        }
        $this->log('Installierte Dateien: ' . count($installedFiles), array('packageId' => $packageId, 'engine' => 'PharData'));
        return array('files' => $installedFiles, 'fileCount' => count($installedFiles), 'backupDir' => $this->safeDisplayPath($backupDir), 'engine' => 'PharData');
    }

    private function normalizeRelativePath($path)
    {
        $path = str_replace('\\', '/', trim($path));
        $path = ltrim($path, '/');
        if ($path === '' || strpos($path, "\0") !== false) {
            throw new Exception('Ungültiger ZIP-Pfad.');
        }
        if (preg_match('#(^|/)\.\.(/|$)#', $path) || preg_match('#^[a-zA-Z]:#', $path)) {
            throw new Exception('Unsicherer ZIP-Pfad blockiert: ' . $path);
        }
        if (preg_match('#(^|/)\.git(/|$)#', $path) || preg_match('#(^|/)\.env$#', $path)) {
            throw new Exception('Geschützter Pfad blockiert: ' . $path);
        }
        return $path;
    }

    private function fetchText($url, $maxBytes)
    {
        if (preg_match('#^https?://#i', $url)) {
            $this->assertAllowedHost($url);
            $context = stream_context_create(array(
                'http' => array(
                    'method' => 'GET',
                    'timeout' => 25,
                    'follow_location' => 1,
                    'header' => "User-Agent: GixFlow-Update-Center/1.0\r\n"
                ),
                'ssl' => array(
                    'verify_peer' => true,
                    'verify_peer_name' => true
                )
            ));
            $data = @file_get_contents($url, false, $context);
            if ($data === false && function_exists('curl_init')) {
                $ch = curl_init($url);
                curl_setopt_array($ch, array(
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_TIMEOUT => 25,
                    CURLOPT_USERAGENT => 'GixFlow-Update-Center/1.0',
                    CURLOPT_SSL_VERIFYPEER => true,
                    CURLOPT_SSL_VERIFYHOST => 2
                ));
                $data = curl_exec($ch);
                $err = curl_error($ch);
                $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                if ($data === false || $code >= 400) {
                    throw new Exception('Remote-Datei konnte nicht geladen werden. ' . $err . ' HTTP ' . $code);
                }
            }
            if ($data === false) {
                throw new Exception('Remote-Datei konnte nicht geladen werden.');
            }
            if (strlen($data) > $maxBytes) {
                throw new Exception('Remote-Datei ist grösser als erlaubt.');
            }
            return $data;
        }
        $path = $this->resolveLocalPath($url);
        if (!is_file($path)) {
            throw new Exception('Lokale Datei nicht gefunden: ' . $url);
        }
        if (filesize($path) > $maxBytes) {
            throw new Exception('Lokale Datei ist grösser als erlaubt.');
        }
        $data = file_get_contents($path);
        if ($data === false) {
            throw new Exception('Lokale Datei konnte nicht gelesen werden: ' . $url);
        }
        return $data;
    }

    private function assertAllowedHost($url)
    {
        $host = strtolower((string)parse_url($url, PHP_URL_HOST));
        if ($host === '') {
            throw new Exception('Remote-Host fehlt.');
        }
        $allowed = isset($this->config['allowedHosts']) && is_array($this->config['allowedHosts']) ? $this->config['allowedHosts'] : array();
        if (!$allowed) {
            return;
        }
        foreach ($allowed as $item) {
            $item = strtolower(trim($item));
            if ($host === $item || substr($host, -strlen('.' . $item)) === '.' . $item) {
                return;
            }
        }
        throw new Exception('Remote-Host ist nicht erlaubt: ' . $host);
    }

    private function resolveLocalPath($path)
    {
        $rel = $this->normalizeRelativePath($path);
        $abs = realpath($this->root . '/' . $rel);
        if ($abs === false) {
            return $this->root . '/' . $rel;
        }
        $root = realpath($this->root);
        if (strpos($abs, $root) !== 0) {
            throw new Exception('Lokaler Pfad liegt ausserhalb von GixFlow: ' . $rel);
        }
        return $abs;
    }

    private function acquireLock()
    {
        if (file_exists($this->lockFile)) {
            $age = time() - filemtime($this->lockFile);
            if ($age < 600) {
                throw new Exception('Es läuft bereits eine Installation. Falls das nicht stimmt: Status zurücksetzen.');
            }
            @unlink($this->lockFile);
        }
        file_put_contents($this->lockFile, date('c'), LOCK_EX);
    }

    private function releaseLock()
    {
        if (file_exists($this->lockFile)) {
            @unlink($this->lockFile);
        }
    }

    private function getInstalledPackages()
    {
        $state = $this->readJson($this->installedFile, array('installed' => array()));
        return isset($state['installed']) && is_array($state['installed']) ? $state['installed'] : array();
    }

    private function markInstalled($id, array $data)
    {
        $state = $this->readJson($this->installedFile, array('installed' => array()));
        if (!isset($state['installed']) || !is_array($state['installed'])) {
            $state['installed'] = array();
        }
        $state['installed'][$id] = $data;
        $state['updatedAt'] = date('c');
        $this->writeJson($this->installedFile, $state);
    }

    private function cleanupBackups()
    {
        $keep = isset($this->config['keepBackups']) ? (int)$this->config['keepBackups'] : 8;
        $dirs = glob($this->baseDir . '/backups/*', GLOB_ONLYDIR);
        if (!$dirs || count($dirs) <= $keep) {
            return;
        }
        usort($dirs, function ($a, $b) { return filemtime($a) <=> filemtime($b); });
        while (count($dirs) > $keep) {
            $dir = array_shift($dirs);
            $this->deleteDir($dir);
        }
    }

    private function deleteDir($dir)
    {
        if (!is_dir($dir)) {
            return;
        }
        $items = scandir($dir);
        foreach ($items as $item) {
            if ($item === '.' || $item === '..') continue;
            $path = $dir . '/' . $item;
            if (is_dir($path)) $this->deleteDir($path); else @unlink($path);
        }
        @rmdir($dir);
    }

    private function readJson($file, $fallback)
    {
        if (!is_file($file)) {
            return $fallback;
        }
        $raw = file_get_contents($file);
        $data = json_decode($raw, true);
        return is_array($data) ? $data : $fallback;
    }

    private function writeJson($file, array $data)
    {
        $dir = dirname($file);
        if (!is_dir($dir)) {
            mkdir($dir, 0755, true);
        }
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (file_put_contents($file, $json, LOCK_EX) === false) {
            throw new Exception('JSON konnte nicht geschrieben werden: ' . $this->safeDisplayPath($file));
        }
    }

    private function safeDisplayPath($path)
    {
        return str_replace($this->root . '/', '', str_replace('\\', '/', $path));
    }
}
