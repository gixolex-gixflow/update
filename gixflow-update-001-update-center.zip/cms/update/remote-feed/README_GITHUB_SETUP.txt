GixFlow Remote Update Feed – kostenloser GitHub-Ablauf

1. Kostenloses GitHub Repository erstellen, z.B. gixflow-updates.
2. Ordner releases/ im Repository erstellen.
3. Deine Update-ZIPs dort hochladen, z.B. releases/gixflow-update-002-core-prep.zip.
4. gixflow-updates.github-example.json kopieren und in gixflow-updates.json umbenennen.
5. In der JSON die url-Felder auf die Raw-URLs deiner ZIP-Dateien setzen.
6. SHA256 jeder ZIP eintragen. Unter Linux/macOS: sha256sum datei.zip. Online-Tools gehen auch, aber lokal ist besser.
7. Raw-URL der gixflow-updates.json im Update Center als Remote Feed URL eintragen.

Wichtig:
- Die Reihenfolge wird über order gesteuert.
- requires verhindert, dass spätere Pakete vor Pflichtpaketen installiert werden.
- GitHub Raw ist am stabilsten. Google Drive geht nur mit echten Direktdownload-Links zuverlässig.
