<?php
require_once __DIR__ . '/../../cms/update/lib/GixflowUpdater.php';

header('Content-Type: application/json; charset=utf-8');
@ini_set('display_errors', '0');
@set_time_limit(180);

function gixflow_json_response($ok, $data = array(), $status = 200) {
    http_response_code($status);
    echo json_encode(array_merge(array('ok' => $ok), $data), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function gixflow_request_data() {
    $raw = file_get_contents('php://input');
    $json = json_decode($raw, true);
    if (is_array($json)) return $json;
    return $_POST ? $_POST : array();
}

function gixflow_token_from_request($data) {
    $headers = function_exists('getallheaders') ? getallheaders() : array();
    foreach ($headers as $key => $value) {
        if (strtolower($key) === 'authorization' && preg_match('/Bearer\s+(.+)/i', $value, $m)) {
            return trim($m[1]);
        }
    }
    if (isset($_SERVER['HTTP_AUTHORIZATION']) && preg_match('/Bearer\s+(.+)/i', $_SERVER['HTTP_AUTHORIZATION'], $m)) {
        return trim($m[1]);
    }
    if (isset($data['token'])) return trim((string)$data['token']);
    if (isset($_POST['token'])) return trim((string)$_POST['token']);
    if (isset($_GET['token'])) return trim((string)$_GET['token']);
    return '';
}

try {
    $updater = new GixflowUpdater();
    $action = isset($_GET['action']) ? $_GET['action'] : (isset($_POST['action']) ? $_POST['action'] : 'status');
    $data = gixflow_request_data();
    $token = gixflow_token_from_request($data);
    $updater->assertToken($token);

    switch ($action) {
        case 'status':
            gixflow_json_response(true, array('status' => $updater->getStatus()));
            break;
        case 'reset-status':
            gixflow_json_response(true, array('status' => $updater->resetStatus()));
            break;
        case 'config':
            gixflow_json_response(true, array('config' => $updater->publicConfig()));
            break;
        case 'save-config':
            gixflow_json_response(true, array('config' => $updater->saveConfigFromInput($data)));
            break;
        case 'self-test':
            gixflow_json_response(true, array('checks' => $updater->selfTest(), 'config' => $updater->publicConfig()));
            break;
        case 'check':
            $feedUrl = isset($data['feedUrl']) ? trim((string)$data['feedUrl']) : null;
            gixflow_json_response(true, $updater->checkFeed($feedUrl));
            break;
        case 'auto-run':
            $feedUrl = isset($data['feedUrl']) ? trim((string)$data['feedUrl']) : null;
            gixflow_json_response(true, array('result' => $updater->autoRun($feedUrl)));
            break;
        case 'install-package':
            $packageId = isset($data['packageId']) ? trim((string)$data['packageId']) : '';
            if ($packageId === '') throw new Exception('packageId fehlt.');
            $feedUrl = isset($data['feedUrl']) ? trim((string)$data['feedUrl']) : null;
            $force = !empty($data['force']);
            gixflow_json_response(true, array('result' => $updater->installPackageFromFeed($packageId, $feedUrl, $force)));
            break;
        case 'upload':
            if (empty($_FILES['package'])) throw new Exception('Upload-Feld package fehlt.');
            gixflow_json_response(true, array('result' => $updater->installUploadedFile($_FILES['package'])));
            break;
        default:
            throw new Exception('Unbekannte Aktion: ' . $action);
    }
} catch (Exception $e) {
    gixflow_json_response(false, array('error' => $e->getMessage()), 400);
}
