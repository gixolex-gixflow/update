<?php
$_GET['action'] = 'upload';
require __DIR__ . '/updater.php';
