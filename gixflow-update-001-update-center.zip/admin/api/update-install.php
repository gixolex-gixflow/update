<?php
$_GET['action'] = 'install-package';
require __DIR__ . '/updater.php';
