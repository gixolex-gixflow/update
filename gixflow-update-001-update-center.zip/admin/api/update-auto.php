<?php
$_GET['action'] = 'auto-run';
require __DIR__ . '/updater.php';
