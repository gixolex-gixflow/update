<?php
$_GET['action'] = 'check';
require __DIR__ . '/updater.php';
