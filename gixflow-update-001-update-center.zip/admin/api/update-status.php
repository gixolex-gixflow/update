<?php
$_GET['action'] = 'status';
require __DIR__ . '/updater.php';
