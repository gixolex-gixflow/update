GixFlow Update Center – Update 1

Aufruf:
/admin/update-center.php

Standard-Token für den ersten Test:
CHANGE_ME_UPDATE1

Bitte nach dem ersten Test sofort im Update Center ändern.

Die API liegt unter:
/admin/api/updater.php

Auto-Run-Endpunkt für Cron-Tests:
/admin/api/update-auto.php?token=DEIN_TOKEN

Der lokale Testfeed liegt unter:
cms/update/remote-feed/gixflow-updates.local-test.json

Das harmlose Testpaket liegt unter:
cms/update/test-packages/gixflow-update-test-001.zip
