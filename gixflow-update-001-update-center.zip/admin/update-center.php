<?php
// GixFlow Update Center – Update 1
?><!doctype html>
<html lang="de">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex,nofollow">
  <title>GixFlow Update Center</title>
  <style>
    :root{--bg:#070b12;--panel:#101827;--panel2:#151f33;--text:#f4f7fb;--muted:#9fb0c8;--line:rgba(255,255,255,.12);--gold:#d7b66b;--blue:#2f7cff;--green:#3fe28f;--red:#ff5d6c;--orange:#ffb14a;--shadow:0 24px 80px rgba(0,0,0,.42);}
    *{box-sizing:border-box} body{margin:0;background:radial-gradient(circle at 20% 0%,rgba(47,124,255,.22),transparent 34%),radial-gradient(circle at 90% 12%,rgba(215,182,107,.16),transparent 30%),var(--bg);color:var(--text);font-family:Inter,system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;min-height:100vh;}
    .wrap{max-width:1180px;margin:0 auto;padding:28px 18px 60px}.hero{border:1px solid var(--line);background:linear-gradient(135deg,rgba(16,24,39,.94),rgba(9,14,24,.9));border-radius:28px;padding:24px;box-shadow:var(--shadow);display:grid;grid-template-columns:1.25fr .75fr;gap:18px;align-items:stretch}.eyebrow{letter-spacing:.14em;text-transform:uppercase;color:var(--gold);font-size:12px;font-weight:800}.hero h1{font-size:clamp(32px,5vw,58px);line-height:.95;margin:10px 0 14px;letter-spacing:-.04em}.hero p{color:var(--muted);font-size:16px;line-height:1.65;margin:0}.statbox{background:rgba(255,255,255,.045);border:1px solid var(--line);border-radius:22px;padding:18px}.statbox strong{display:block;font-size:24px;margin-bottom:8px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px;margin-top:18px}.card{background:rgba(16,24,39,.88);border:1px solid var(--line);border-radius:24px;padding:20px;box-shadow:0 18px 60px rgba(0,0,0,.24)}.card h2{margin:0 0 12px;font-size:22px}.row{display:grid;grid-template-columns:1fr 1fr;gap:12px}.field{display:flex;flex-direction:column;gap:7px;margin:10px 0}.field label{font-size:13px;color:var(--muted);font-weight:700}.field input,.field textarea,.field select{width:100%;border:1px solid var(--line);background:#080d16;color:var(--text);border-radius:14px;padding:12px 13px;font:inherit;outline:none}.field textarea{min-height:82px;resize:vertical}.actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:14px}.btn{border:1px solid var(--line);background:linear-gradient(135deg,rgba(47,124,255,.95),rgba(22,78,180,.95));color:white;border-radius:999px;padding:11px 16px;font-weight:800;cursor:pointer;transition:.18s transform,.18s opacity}.btn:hover{transform:translateY(-1px)}.btn.secondary{background:rgba(255,255,255,.06);color:var(--text)}.btn.gold{background:linear-gradient(135deg,#e0c174,#a9822d);color:#101010}.btn.danger{background:linear-gradient(135deg,#ff5d6c,#a92735)}.btn:disabled{opacity:.55;cursor:not-allowed;transform:none}.notice{border:1px solid rgba(255,177,74,.35);background:rgba(255,177,74,.08);border-radius:18px;padding:12px 14px;color:#ffdda8;font-size:14px;margin:12px 0}.ok{color:var(--green)}.bad{color:var(--red)}.muted{color:var(--muted)}.progress{height:13px;background:#070b12;border:1px solid var(--line);border-radius:999px;overflow:hidden}.bar{height:100%;width:0%;background:linear-gradient(90deg,var(--blue),var(--gold));transition:.25s width}.log{max-height:330px;overflow:auto;background:#070b12;border:1px solid var(--line);border-radius:16px;padding:12px;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px;line-height:1.55}.log div{border-bottom:1px solid rgba(255,255,255,.06);padding:6px 0}.pkg{display:grid;grid-template-columns:70px 1fr auto;gap:12px;align-items:center;border:1px solid var(--line);background:rgba(255,255,255,.035);border-radius:18px;padding:12px;margin:10px 0}.badge{display:inline-flex;align-items:center;gap:6px;border:1px solid var(--line);border-radius:999px;padding:6px 9px;font-size:12px;color:var(--muted);font-weight:800}.checks{display:grid;gap:8px}.check{display:flex;align-items:center;justify-content:space-between;background:rgba(255,255,255,.035);border:1px solid var(--line);border-radius:14px;padding:10px 12px}.fileline{font-size:13px;color:var(--muted);word-break:break-word}.toplinks{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px}.toplinks a{color:var(--gold);text-decoration:none;font-weight:800}@media(max-width:850px){.hero,.grid,.row{grid-template-columns:1fr}.pkg{grid-template-columns:1fr}.wrap{padding:16px 12px 40px}.card,.hero{border-radius:20px}}
  </style>
</head>
<body>
<div class="wrap">
  <section class="hero">
    <div>
      <div class="eyebrow">GIXFLOW CORE · UPDATE 1</div>
      <h1>Update Center</h1>
      <p>Remote-Feed prüfen, ZIP-Pakete in definierter Reihenfolge installieren, manuelle ZIPs hochladen und jeden Installationsschritt per AJAX verfolgen. Für GitHub-Raw, direkte ZIP-Links und lokale Testpakete vorbereitet.</p>
      <div class="toplinks"><a href="../index.html">Zur Website</a><a href="../docs/GIXFLOW_UPDATE_SYSTEM.md">Update-Doku</a></div>
    </div>
    <div class="statbox">
      <strong id="stateLabel">Bereit</strong>
      <div class="progress"><div class="bar" id="bar"></div></div>
      <p id="stateMsg" class="muted" style="margin-top:12px">Noch keine Aktion gestartet.</p>
      <p class="fileline" id="currentFile"></p>
    </div>
  </section>

  <div id="tokenNotice" class="notice">Erster Test: Standard-Token <strong>CHANGE_ME_UPDATE1</strong>. Danach bitte sofort einen eigenen Token speichern.</div>

  <section class="grid">
    <div class="card">
      <h2>1 · Verbindung & Einstellungen</h2>
      <div class="field"><label>Sicherheitstoken</label><input id="token" type="password" value="CHANGE_ME_UPDATE1" autocomplete="off"></div>
      <div class="row">
        <div class="field"><label>Channel</label><select id="channel"><option value="stable">stable</option><option value="beta">beta</option><option value="dev">dev</option></select></div>
        <div class="field"><label>Auto-Check alle Stunden</label><input id="autoCheckHours" type="number" min="1" value="12"></div>
      </div>
      <div class="field"><label>Remote Feed URL oder lokaler Pfad</label><input id="feedUrl" type="text" placeholder="cms/update/remote-feed/gixflow-updates.local-test.json"></div>
      <div class="field"><label>Erlaubte Hosts für Remote-Dateien</label><textarea id="allowedHosts">raw.githubusercontent.com, github.com, gist.githubusercontent.com, dl.dropboxusercontent.com, dropbox.com, drive.google.com</textarea></div>
      <div class="row">
        <label class="field"><span>Auto-Check aktiv</span><select id="autoCheckEnabled"><option value="false">Nein</option><option value="true">Ja</option></select></label>
        <label class="field"><span>Auto-Install aktiv</span><select id="autoInstallEnabled"><option value="false">Nein</option><option value="true">Ja</option></select></label>
      </div>
      <div class="field"><label>Neuer Token nur wenn ändern</label><input id="newAccessToken" type="text" placeholder="z.B. langer-zufalls-token-2026"></div>
      <div class="actions"><button class="btn secondary" onclick="loadConfig()">Konfig laden</button><button class="btn gold" onclick="saveConfig()">Konfig speichern</button><button class="btn secondary" onclick="selfTest()">Selbsttest</button></div>
    </div>

    <div class="card">
      <h2>2 · Status & Protokoll</h2>
      <div class="actions"><button class="btn secondary" onclick="refreshStatus()">Status aktualisieren</button><button class="btn danger" onclick="resetStatus()">Status zurücksetzen</button></div>
      <div style="height:14px"></div>
      <div id="checks" class="checks"></div>
      <div style="height:14px"></div>
      <div class="log" id="log"><div>Bereit.</div></div>
    </div>
  </section>

  <section class="grid">
    <div class="card">
      <h2>3 · Feed prüfen & Reihenfolge installieren</h2>
      <p class="muted">Der lokale Testfeed ist bereits eingetragen. Für GitHub später einfach die Raw-URL deiner JSON-Datei einsetzen.</p>
      <div class="actions"><button class="btn" onclick="checkFeed()">Feed prüfen</button><button class="btn secondary" onclick="autoRun()">Auto-Run testen</button><button class="btn gold" onclick="installPlan()" id="installPlanBtn" disabled>Plan installieren</button></div>
      <div id="packages" style="margin-top:14px"></div>
    </div>

    <div class="card">
      <h2>4 · Manuelles ZIP installieren</h2>
      <p class="muted">Für direkte Tests kannst du ein Update-ZIP auswählen. Die Installation läuft über AJAX, erstellt Backups und protokolliert jede Datei.</p>
      <div class="field"><label>ZIP-Datei</label><input id="packageFile" type="file" accept=".zip,application/zip"></div>
      <div class="actions"><button class="btn" onclick="uploadPackage()">ZIP hochladen & installieren</button></div>
      <div class="notice">Test-ZIP im Paket: <strong>cms/update/test-packages/gixflow-update-test-001.zip</strong>. Dieses schreibt nur eine harmlose Testdatei.</div>
    </div>
  </section>
</div>
<script>
const apiUrl = 'api/updater.php';
let lastPlan = [];
let polling = null;
const els = id => document.getElementById(id);
function token(){ const t = els('token').value.trim(); localStorage.setItem('gixflowUpdateToken', t); return t; }
function initToken(){ const saved = localStorage.getItem('gixflowUpdateToken'); if(saved) els('token').value = saved; }
async function api(action, body={}){
  const res = await fetch(apiUrl + '?action=' + encodeURIComponent(action), {method:'POST', headers:{'Content-Type':'application/json','Authorization':'Bearer '+token()}, body:JSON.stringify(body)});
  const data = await res.json().catch(()=>({ok:false,error:'JSON-Antwort konnte nicht gelesen werden.'}));
  if(!data.ok) throw new Error(data.error || 'API Fehler');
  return data;
}
function startPolling(){ if(polling) clearInterval(polling); polling = setInterval(refreshStatus, 900); }
function stopPollingSoon(){ setTimeout(()=>{ if(polling){ clearInterval(polling); polling=null; } refreshStatus(); }, 1400); }
function setBusy(b){ document.querySelectorAll('.btn').forEach(btn=>{ if(btn.id !== 'installPlanBtn') btn.disabled=b; }); if(!b && lastPlan.some(p=>p.canInstall)) els('installPlanBtn').disabled=false; }
function renderStatus(status){
  els('stateLabel').textContent = (status.state || 'idle').toUpperCase();
  els('stateMsg').textContent = status.message || 'Bereit.';
  els('bar').style.width = Math.max(0, Math.min(100, Number(status.progress||0))) + '%';
  els('currentFile').textContent = status.currentFile ? 'Aktuelle Datei: ' + status.currentFile : '';
  const logs = (status.logs||[]).slice().reverse().map(l=>`<div><span class="muted">${escapeHtml((l.time||'').replace('T',' ').slice(0,19))}</span> · ${escapeHtml(l.message||'')}</div>`).join('');
  els('log').innerHTML = logs || '<div>Keine Logs.</div>';
}
async function refreshStatus(){ try{ const data = await api('status'); renderStatus(data.status); }catch(e){ els('stateMsg').textContent=e.message; }}
async function resetStatus(){ try{ const data = await api('reset-status'); renderStatus(data.status); }catch(e){ alert(e.message); }}
async function loadConfig(){
  try{ const data = await api('config'); applyConfig(data.config); }catch(e){ alert(e.message); }
}
function applyConfig(c){
  if(!c) return;
  els('feedUrl').value = c.remoteFeedUrl || '';
  els('channel').value = c.channel || 'stable';
  els('autoCheckHours').value = c.autoCheckHours || 12;
  els('autoCheckEnabled').value = c.autoCheckEnabled ? 'true':'false';
  els('autoInstallEnabled').value = c.autoInstallEnabled ? 'true':'false';
  els('allowedHosts').value = (c.allowedHosts||[]).join(', ');
  els('tokenNotice').style.display = c.tokenIsDefault ? 'block':'none';
}
async function saveConfig(){
  try{
    const newToken = els('newAccessToken').value.trim();
    const payload = {remoteFeedUrl:els('feedUrl').value.trim(), channel:els('channel').value, autoCheckHours:els('autoCheckHours').value, autoCheckEnabled:els('autoCheckEnabled').value, autoInstallEnabled:els('autoInstallEnabled').value, allowedHosts:els('allowedHosts').value, newAccessToken:newToken};
    const data = await api('save-config', payload);
    if(newToken){ els('token').value = newToken; localStorage.setItem('gixflowUpdateToken', newToken); els('newAccessToken').value=''; }
    applyConfig(data.config); alert('Konfiguration gespeichert.');
  }catch(e){ alert(e.message); }
}
async function selfTest(){
  try{
    const data = await api('self-test');
    els('checks').innerHTML = data.checks.map(c=>`<div class="check"><span>${escapeHtml(c.label)} <span class="muted">${escapeHtml(c.value)}</span></span><strong class="${c.ok?'ok':'bad'}">${c.ok?'OK':'FEHLER'}</strong></div>`).join('');
    applyConfig(data.config);
  }catch(e){ alert(e.message); }
}
async function checkFeed(){
  try{
    setBusy(true); startPolling();
    const data = await api('check', {feedUrl:els('feedUrl').value.trim()});
    lastPlan = data.plan || [];
    renderPackages(lastPlan);
    applyConfig(data.config);
  }catch(e){ alert(e.message); }
  finally{ setBusy(false); stopPollingSoon(); }
}
function renderPackages(plan){
  els('installPlanBtn').disabled = !plan.some(p=>p.canInstall);
  els('packages').innerHTML = plan.map(p=>{
    const state = p.installed ? '<span class="badge ok">installiert</span>' : (p.canInstall ? '<span class="badge">bereit</span>' : '<span class="badge bad">blockiert</span>');
    const missing = (p.missingRequires||[]).length ? `<div class="fileline bad">Fehlt: ${escapeHtml(p.missingRequires.join(', '))}</div>` : '';
    return `<div class="pkg"><div class="badge">#${escapeHtml(String(p.order||'-'))}</div><div><strong>${escapeHtml(p.title||p.id)}</strong><div class="fileline">${escapeHtml(p.version||'')} · ${escapeHtml(p.url||'')}</div>${missing}</div><div>${state}</div></div>`;
  }).join('') || '<p class="muted">Keine Pakete im Feed gefunden.</p>';
}
async function autoRun(){
  try{
    setBusy(true); startPolling();
    const data = await api('auto-run', {feedUrl:els('feedUrl').value.trim()});
    alert(data.result.message || 'Auto-Run abgeschlossen.');
    await checkFeed();
  }catch(e){ alert(e.message); }
  finally{ setBusy(false); stopPollingSoon(); }
}
async function installPlan(){
  const todo = lastPlan.filter(p=>p.canInstall);
  if(!todo.length) return alert('Keine installierbaren Pakete im Plan.');
  if(!confirm('Jetzt '+todo.length+' Paket(e) in Reihenfolge installieren?')) return;
  setBusy(true); startPolling();
  try{
    for(const p of todo){
      await api('install-package', {packageId:p.id, feedUrl:els('feedUrl').value.trim()});
    }
    await checkFeed();
    alert('Update-Plan installiert.');
  }catch(e){ alert(e.message); }
  finally{ setBusy(false); stopPollingSoon(); }
}
async function uploadPackage(){
  const file = els('packageFile').files[0];
  if(!file) return alert('Bitte ZIP-Datei wählen.');
  if(!confirm('Manuelles ZIP wirklich installieren?')) return;
  setBusy(true); startPolling();
  try{
    const fd = new FormData(); fd.append('token', token()); fd.append('package', file);
    const res = await fetch(apiUrl + '?action=upload', {method:'POST', body:fd});
    const data = await res.json();
    if(!data.ok) throw new Error(data.error||'Upload fehlgeschlagen');
    alert('ZIP installiert.');
  }catch(e){ alert(e.message); }
  finally{ setBusy(false); stopPollingSoon(); }
}
function escapeHtml(str){ return String(str).replace(/[&<>'"]/g, ch=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[ch])); }
initToken(); refreshStatus(); selfTest();
</script>
</body>
</html>
