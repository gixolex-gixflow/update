# GixFlow Update Center – Update 1

Dieses Update ergänzt GixFlow um ein erstes serverseitiges Update-System mit PHP, AJAX-Status und ZIP-Installation. Es ist bewusst als Fundament gebaut: zuerst testen wir Check, Upload, Entpacken, Backup und Protokoll. Danach kann Update 2 Kunden-/Multisite-Rollouts und automatische Client-Installation erweitern.

## Was neu ist

- `/admin/update-center.php` als Bedienoberfläche.
- `/admin/api/updater.php` als zentrale AJAX-API.
- Remote-Feed per JSON-Datei.
- Paket-Reihenfolge über `order`.
- Abhängigkeiten über `requires`.
- Manuelle ZIP-Installation über Upload.
- Statusdatei mit Fortschritt, aktueller Datei und Log.
- Backup vorhandener Dateien vor dem Überschreiben.
- Lokaler Testfeed inklusive harmlosem Testpaket.
- Optionaler Auto-Run-Endpunkt `/admin/api/update-auto.php?token=DEIN_TOKEN` für externe kostenlose Cron-Dienste.

## Erster Test

1. Patch in das Root-Verzeichnis der aktuellen GixFlow-Installation entpacken.
2. `/admin/update-center.php` öffnen.
3. Standard-Token verwenden: `CHANGE_ME_UPDATE1`.
4. `Selbsttest` ausführen.
5. `Feed prüfen` klicken.
6. `Plan installieren` klicken.
7. Prüfen, ob diese Datei existiert: `cms/update/test-results/update-1-test.txt`.
8. Danach im Update Center sofort einen eigenen langen Token speichern.

## Feed-Struktur

```json
{
  "feedVersion": 1,
  "project": "gixflow-core",
  "channel": "stable",
  "latest": "11.3.0",
  "packages": [
    {
      "id": "gixflow-update-002-core-prep",
      "title": "Update 2",
      "version": "11.3.0",
      "order": 1,
      "required": true,
      "url": "https://raw.githubusercontent.com/user/repo/main/releases/update.zip",
      "sha256": "...",
      "requires": []
    }
  ]
}
```

## Sicherheit

Der Updater blockiert unsichere ZIP-Pfade wie `../`, absolute Pfade, `.git/` und `.env`. Vor überschriebenen Dateien wird ein Backup unter `cms/update/backups/` erstellt. Remote-Downloads sind auf konfigurierte Hosts begrenzbar.

## Automatischer Check

Im Update Center kann Auto-Check aktiviert werden. Für echtes zeitgesteuertes Prüfen ohne eigenen Server-Cron kann ein kostenloser externer Cron-Dienst die URL `/admin/api/update-auto.php?token=DEIN_LANGER_TOKEN` aufrufen. Auto-Install bleibt standardmässig aus und sollte erst nach Tests aktiviert werden.

## Kostenloser Betrieb

Empfohlen ist ein kostenloses GitHub-Repository mit einer JSON-Datei und ZIP-Dateien im Ordner `releases/`. Das GixFlow Update Center liest nur die JSON-Datei und lädt die ZIP-Dateien in der definierten Reihenfolge.

## Nächster sinnvoller Schritt

Update 2 sollte den Kunden-/Multisite-Teil ergänzen:

- Kundenprofil anlegen.
- Zielserver/Client-Pfad speichern.
- Minimal-Client erzeugen.
- Client holt Core-Konfiguration vom Hauptsystem.
- Update-Rollout je Kunde planen.
- Traffic-sparsame Manifest-/Hash-Prüfung.
