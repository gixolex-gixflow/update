Gixolex Media Development – GixFlow Core
Version 10.1 Language & Performance Patch

Dieses ZIP/Patch-Set erweitert Version 10 um:
- übersetzbare Sprachdateien für sichtbare Basis-Texte
- DE/EN-Sprachstruktur mit Browser-Erkennung und manueller Auswahl
- Sprach-Dropdown mit Landesflaggen
- Lazy Loading für Bilder und externe Hintergrundbilder
- Footer-Menü als App-Einstellung ein-/ausschaltbar
- neue i18n- und Lazy-Loading-Module
- aktualisierte Service-Worker-Cache-Version

Technische Basis:
- statisches Frontend
- kein PHP
- PWA / Service Worker
- AJAX-Seitenladung
- JSON-Datenstruktur
- externe Bibliotheken per CDN, interne Systemmodule lokal


V10.4 PAGE HEADER / I18N / GIXFLOW UPDATE

- Jede Unterseite erhält einen einheitlicheren Header mit Hintergrundbild, Parallax-Effekt und animiertem Titel.
- Startseiten-Slider-Navigation und Proof-Boxen wurden getrennt.
- GixFlow-Seite wurde deutlich ausgebaut.
- Zentrale UI- und Inhaltsübersetzungen wurden erweitert.

V10.3 TEMPLATE SYSTEM
=====================
- CMS Core, Templates, Content/Sprachdaten und Extensions sind ab Version 10.3 klarer getrennt.
- Core-Dateien: cms/core und assets/js
- Template-Dateien: templates/<template-id>/template.json + theme.css
- Erweiterungen: extensions/<extension-id>/manifest.json + optionale JS/CSS-Dateien
- Inhalte und Sprachdateien bleiben in assets/data sowie assets/data/de und assets/data/en.
- Für Kundenprojekte kann ein neues Template angelegt werden, ohne den Core umzubauen.

V10.6 BIG UPDATE / FULL WEBSITE PACKAGE
--------------------------------------
- Startseite neu strukturiert: Slider, Slider-Navigation, Infobox und Kernboxen sind sauber getrennt.
- Kernboxen erweitert: Webdesign, Printdesign, SEO und Webapps.
- FAQ von der Startseite entfernt und stattdessen Projektkosten-Rechner als CTA ergänzt.
- Projektkosten-Rechner erstellt: Umfang, Funktionen, Design, Inhalt und Wartung auswählbar; Richtpreis wird automatisch berechnet; Zusammenfassung kann kopiert oder über FormSubmit als Anfrage gesendet werden.
- Route, Navigation, Suche, SEO-Metadaten, Changelog, Manifest und Service Worker aktualisiert.
- Übersetzungsprüfung für HTML-Seiten durchgeführt: sichtbare Texte sind in der DE/EN-Sprachstruktur vorhanden.
- Seitenstruktur geprüft: alle Unterseiten ausser Startseite und Wartungsseite beginnen mit Parallax-Seitenheader.
- Service Worker cached nur das aktive Template gixolex-premium, nicht das Beispieltemplate client-clean.


============================================================
GIXOLEX / GIXFLOW CORE 11.0
============================================================
Diese Full-ZIP enthält alle aktuellen Dateien des GixFlow-Systems.

Wichtige V11-Punkte:
- Core-CSS: cms/core/css/core.css
- Aktives Template-CSS: templates/gixolex-premium/css/
- Template-Wechsel nur über Config, nicht im Frontend.
- Service Worker cached nur das aktive Template für Offline-Nutzung.
- Mobiles Footer-Menü als ausklappbarer Gold-Dock.
- Social Media Icons als ausklappbare Sidebar.
- Update wird erst nach Klick auf Aktualisieren aktiviert.
- Alte GixFlow-Caches werden beim Aktivieren bereinigt, lokale Nutzereinstellungen bleiben erhalten.


============================================================
GIXOLEX / GIXFLOW CORE 11.1
============================================================
Dieses Update ergänzt die professionelle Template-Konfiguration und die Dokumentation.

Neu:
- Projektweite Basisdaten liegen in cms/config/site.json.
- CMS-Struktur und aktives Template liegen in cms/config/cms.json.
- Jedes Template besitzt eine eigene templates/<template-id>/config.json.
- Das aktive Template steuert Navbar-Position, Menü-Icon-Seite, Logo-Position, Suche, Social Rail, Mobile Dock, Footer, Motion, Farben und Section-Stil.
- Social Links bleiben in der Basis-Config und werden vom Template nur angezeigt oder verborgen.
- Die neue Seite pages/gixflow-doku.html enthält die Gebrauchsanweisung für Installation, Config, Templates, Sprache, PWA, Wartung, Updates, Extensions und GitHub.
- Die Dokumentation ist nicht im Hauptmenü verlinkt, sondern nur von der GixFlow-Seite aus erreichbar.
- App-Icon-Set erweitert: favicon, Apple Touch Icon, Android/PWA-Grössen und maskable Icons.
- Vorbereitung für GitHub ergänzt: .gitignore und docs/GIXFLOW_DOKUMENTATION.md.

Wichtige Regel:
Core-Funktionen gehören in cms/core.
Template-Design gehört in templates/<template-id>/.
Projektweite Angaben gehören in cms/config/site.json.
Kundeninhalte und Sprachdaten gehören in assets/data/de und assets/data/en.


============================================================
GIXOLEX / GIXFLOW CORE 11.2 – UPDATE 1
============================================================
Dieses Teilupdate ergänzt das erste testbare GixFlow Update Center.

Neu:
- Admin-Oberfläche unter admin/update-center.php.
- PHP/AJAX-API unter admin/api/updater.php.
- Remote-Update-Feed per JSON-Datei.
- ZIP-Pakete werden über order in fester Reihenfolge installiert.
- Paket-Abhängigkeiten werden über requires geprüft.
- Manuelle ZIP-Installation mit Fortschritt, aktueller Datei und Log.
- Backup vorhandener Dateien vor dem Überschreiben.
- Lokaler Testfeed und harmloses Testpaket für den ersten Funktionstest.
- GitHub-Feed-Beispiel für kostenlose Update-Bereitstellung vorbereitet.

Erster Aufruf:
/admin/update-center.php

Standard-Token für den ersten Test:
CHANGE_ME_UPDATE1

Danach bitte direkt einen eigenen langen Token speichern.
