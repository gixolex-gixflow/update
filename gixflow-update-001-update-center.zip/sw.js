const CACHE_NAME="gixolex-v11-2-update-center";
const STATIC_ASSETS=["./","./README.txt","./app-einstellungen.html","./app-info.html","./assets/css/style.css","./assets/data/benefits.json","./assets/data/blog-categories.json","./assets/data/blog-posts.json","./assets/data/changelog.json","./assets/data/de/benefits.json","./assets/data/de/blog-categories.json","./assets/data/de/blog-posts.json","./assets/data/de/changelog.json","./assets/data/de/faq.json","./assets/data/de/hero-slides.json","./assets/data/de/i18n.json","./assets/data/de/pricing.json","./assets/data/de/search-index.json","./assets/data/de/services.json","./assets/data/de/site-settings.json","./assets/data/de/social-links.json","./assets/data/de/tech-stacks.json","./assets/data/de/tools.json","./assets/data/en/benefits.json","./assets/data/en/blog-categories.json","./assets/data/en/blog-posts.json","./assets/data/en/changelog.json","./assets/data/en/faq.json","./assets/data/en/hero-slides.json","./assets/data/en/i18n.json","./assets/data/en/pricing.json","./assets/data/en/search-index.json","./assets/data/en/services.json","./assets/data/en/site-settings.json","./assets/data/en/social-links.json","./assets/data/en/tech-stacks.json","./assets/data/en/tools.json","./assets/data/faq.json","./assets/data/hero-slides.json","./assets/data/i18n.json","./assets/data/pricing.json","./assets/data/search-index.json","./assets/data/services.json","./assets/data/site-settings.json","./assets/data/social-links.json","./assets/data/tech-stacks.json","./assets/data/tools.json","./assets/img/app-icon-192.png","./assets/img/app-icon-512.png","./assets/img/app-icon.png","./assets/img/app-icon.svg","./assets/img/gixolex-logo.png","./assets/img/gixolex-logo.svg","./assets/img/hero-media.svg","./assets/img/icons/app-icon-128.png","./assets/img/icons/app-icon-144.png","./assets/img/icons/app-icon-152.png","./assets/img/icons/app-icon-16.png","./assets/img/icons/app-icon-256.png","./assets/img/icons/app-icon-32.png","./assets/img/icons/app-icon-384.png","./assets/img/icons/app-icon-48.png","./assets/img/icons/app-icon-72.png","./assets/img/icons/app-icon-96.png","./assets/img/icons/apple-touch-icon.png","./assets/img/icons/maskable-192.png","./assets/img/icons/maskable-512.png","./assets/img/og-image.svg","./assets/js/analytics.js","./assets/js/app.js","./assets/js/config.js","./assets/js/cookie-consent.js","./assets/js/data-loader.js","./assets/js/easter-eggs.js","./assets/js/hero-slider.js","./assets/js/i18n.js","./assets/js/lang.js","./assets/js/lazy.js","./assets/js/maintenance.js","./assets/js/pwa.js","./assets/js/search.js","./assets/js/seo.js","./assets/js/settings.js","./assets/js/site-check.js","./assets/js/toolkit.js","./assets/js/ui.js","./cms/config/cms.json","./cms/config/extensions.json","./cms/config/site.json","./cms/core/cms-api.js","./cms/core/css/core.css","./cms/core/extension-loader.js","./cms/core/template-config.js","./cms/core/template-engine.js","./extensions/site-check/extension.js","./extensions/site-check/manifest.json","./extensions/template-debug/extension.js","./extensions/template-debug/manifest.json","./faq.html","./gixflow-doku.html","./index.html","./kontakt.html","./leistungen.html","./manifest.json","./pages/404.html","./pages/ai-studio.html","./pages/app-einstellungen.html","./pages/app-info.html","./pages/blog-atomic-design.html","./pages/blog-gixflow.html","./pages/blog-pwa-updates.html","./pages/blog-pwa-websites.html","./pages/blog-seo-sichtbarkeit.html","./pages/blog-tracking-seo.html","./pages/blog-wartung.html","./pages/blog-webdesign-vertrauen.html","./pages/blog.html","./pages/cookies.html","./pages/datenschutz.html","./pages/faq.html","./pages/gixflow-doku.html","./pages/home.html","./pages/impressum.html","./pages/kontakt.html","./pages/leistungen.html","./pages/maintenance.html","./pages/portfolio.html","./pages/preise.html","./pages/print-media.html","./pages/projektkosten.html","./pages/seo.html","./pages/systeme.html","./pages/tool-seo-meta.html","./pages/tools.html","./pages/wartung.html","./pages/webapps.html","./print-media.html","./projektkosten.html","./robots.txt","./seo.html","./sitemap.xml","./sw.js","./systeme.html","./templates/gixolex-premium/config.json","./templates/gixolex-premium/css/motion.css","./templates/gixolex-premium/css/sections.css","./templates/gixolex-premium/css/template.css","./templates/gixolex-premium/partials.json","./templates/gixolex-premium/template.json","./templates/gixolex-premium/theme.css","./tool-seo-meta.html","./tools.html","./wartung.html","./webapps.html"];
self.addEventListener("install",event=>{
  event.waitUntil(caches.open(CACHE_NAME).then(async cache=>{
    for(const asset of STATIC_ASSETS){
      try{ await cache.add(asset); }catch(error){ console.warn("GIXOLEX cache asset skipped", asset, error); }
    }
  }).catch(error=>console.warn("GIXOLEX cache install", error)));
});
self.addEventListener("activate",event=>{
  event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key!==CACHE_NAME && key.startsWith("gixolex-")).map(key=>caches.delete(key)))).then(()=>self.clients.claim()));
});
self.addEventListener("message",event=>{
  if(event.data&&event.data.type==="SKIP_WAITING") self.skipWaiting();
  if(event.data&&event.data.type==="CLEAR_OLD_CACHES") {
    event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(key=>key!==CACHE_NAME && key.startsWith("gixolex-")).map(key=>caches.delete(key))))); 
  }
});
function isFreshRequest(request){
  const url=new URL(request.url);
  const path=url.pathname;
  return request.mode==="navigate"||path.endsWith(".html")||path.endsWith(".css")||path.endsWith(".js")||path.endsWith(".json")||path.includes("/pages/")||path.includes("/cms/core/")||path.includes("/cms/config/")||path.includes("/templates/gixolex-premium/")||path.endsWith("manifest.json");
}
async function networkFirst(request){
  const cache=await caches.open(CACHE_NAME);
  try{
    const fresh=await fetch(request,{cache:"no-store"});
    if(fresh&&fresh.ok) cache.put(request,fresh.clone());
    return fresh;
  }catch(error){
    const cached=await cache.match(request,{ignoreSearch:true});
    if(cached) return cached;
    if(request.mode==="navigate") return cache.match("./index.html");
    throw error;
  }
}
async function cacheFirst(request){
  const cache=await caches.open(CACHE_NAME);
  const cached=await cache.match(request,{ignoreSearch:true});
  if(cached) return cached;
  const fresh=await fetch(request);
  if(fresh&&fresh.ok) cache.put(request,fresh.clone());
  return fresh;
}
self.addEventListener("fetch",event=>{
  if(event.request.method!=="GET") return;
  event.respondWith(isFreshRequest(event.request)?networkFirst(event.request):cacheFirst(event.request));
});
